import StockApp from "./StockApp";
export default function App() {
  return <StockApp />;
}
