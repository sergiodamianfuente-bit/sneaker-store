import { useState, useEffect } from "react";

const talles = Array.from({ length: 14 }, (_, i) => 34 + i);

export default function StockApp() {
  const [productos, setProductos] = useState([]);
  const [busqueda, setBusqueda] = useState("");
  const [ventas, setVentas] = useState([]);

  const [nuevo, setNuevo] = useState({
    marca: "",
    modelo: "",
    precio: "",
    recargo: "",
    stockPorTalle: talles.reduce((acc, t) => ({ ...acc, [t]: 0 }), {}),
  });

  useEffect(() => {
    const data = localStorage.getItem("stock_zapas");
    const ventasData = localStorage.getItem("ventas_zapas");
    if (data) setProductos(JSON.parse(data));
    if (ventasData) setVentas(JSON.parse(ventasData));
  }, []);

  useEffect(() => {
    localStorage.setItem("stock_zapas", JSON.stringify(productos));
    localStorage.setItem("ventas_zapas", JSON.stringify(ventas));
  }, [productos, ventas]);

  const agregarProducto = () => {
    setProductos([...productos, { ...nuevo, id: Date.now() }]);
    setNuevo({
      marca: "",
      modelo: "",
      precio: "",
      recargo: "",
      stockPorTalle: talles.reduce((acc, t) => ({ ...acc, [t]: 0 }), {}),
    });
  };

  const cambiarStock = (talle, valor) => {
    setNuevo({
      ...nuevo,
      stockPorTalle: {
        ...nuevo.stockPorTalle,
        [talle]: Number(valor),
      },
    });
  };

  const vender = (id, talle) => {
    setProductos(productos.map(p => {
      if (p.id === id && p.stockPorTalle[talle] > 0) {
        const precioFinal = calcularPrecioFinal(p.precio, p.recargo);

        setVentas([...ventas, {
          id: Date.now(),
          producto: p.marca + " " + p.modelo,
          talle,
          precio: precioFinal
        }]);

        return {
          ...p,
          stockPorTalle: {
            ...p.stockPorTalle,
            [talle]: p.stockPorTalle[talle] - 1,
          },
        };
      }
      return p;
    }));
  };

  const calcularPrecioFinal = (precio, recargo) => {
    const p = parseFloat(precio) || 0;
    const r = parseFloat(recargo) || 0;
    return Math.round(p + (p * r) / 100);
  };

  const filtrados = productos.filter(p =>
    (p.marca + " " + p.modelo).toLowerCase().includes(busqueda.toLowerCase())
  );

  const totalStock = productos.reduce((acc, p) => {
    return acc + Object.values(p.stockPorTalle).reduce((a, b) => a + b, 0);
  }, 0);

  const gananciaTotal = ventas.reduce((acc, v) => acc + v.precio, 0);

  return (
    <div style={{background:"black", color:"white", minHeight:"100vh", padding:20}}>
      <h1 style={{color:"red"}}>Sneaker Store</h1>
      <p>Stock: {totalStock} | $ {gananciaTotal}</p>
      <p>App lista para subir 🚀</p>
    </div>
  );
}
